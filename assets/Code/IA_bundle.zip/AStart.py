
#%%
import heapq

# Definición de la heurística (estimación de la distancia de cada nodo al objetivo)
def heuristica(nodo, objetivo):
    # Usaremos la heurística de la distancia Manhattan
    x1, y1 = nodo
    x2, y2 = objetivo
    return abs(x1 - x2) + abs(y1 - y2)

# Algoritmo A*
def a_star(graph, start, goal):
    # Cola de prioridad (heap) para mantener los nodos abiertos
    open_list = []
    heapq.heappush(open_list, (0, start))  # (costo f(n), nodo)

    # Diccionarios para rastrear el costo g(n) y el camino
    g_cost = {start: 0}  # Costo del camino desde el inicio hasta el nodo actual
    came_from = {start: None}  # Para reconstruir el camino

    while open_list:
        # Obtener el nodo con el menor costo f(n)
        current = heapq.heappop(open_list)[1]

        # Si llegamos al nodo objetivo, reconstruimos el camino
        if current == goal:
            path = []
            while current:
                print(current)
                path.append(current)
                current = came_from[current]
            path.reverse()
            return path

        # Explorar los vecinos
        for neighbor, cost in graph[current]:
            tentative_g_cost = g_cost[current] + cost

            if neighbor not in g_cost or tentative_g_cost < g_cost[neighbor]:
                # Actualizamos el mejor costo g(n) encontrado para este vecino
                g_cost[neighbor] = tentative_g_cost
                f_cost = tentative_g_cost + heuristica(neighbor, goal)  # f(n) = g(n) + h(n)
                heapq.heappush(open_list, (f_cost, neighbor))
                came_from[neighbor] = current

    return None  # No se encontró un camino

# Definición de un grafo como un diccionario
# Cada nodo tiene una lista de tuplas (vecino, costo)
grafo = {
    (0, 0): [((1, 0), 1), ((0, 1), 1)],
    (1, 0): [((0, 0), 1), ((2, 0), 1), ((1, 1), 1)],
    (2, 0): [((1, 0), 1), ((2, 1), 1)],
    (0, 1): [((0, 0), 1), ((1, 1), 1)],
    (1, 1): [((0, 1), 1), ((1, 0), 1), ((2, 1), 1), ((1, 2), 1)],
    (2, 1): [((1, 1), 1), ((2, 0), 1), ((2, 2), 1)],
    (1, 2): [((1, 1), 1), ((2, 2), 1)],
    (2, 2): [((1, 2), 1), ((2, 1), 1)],
}

# Definir el nodo de inicio y el nodo objetivo
inicio = (0, 0)
objetivo = (2, 2)

# Ejecutar A*
camino = a_star(grafo, inicio, objetivo)
print("Camino más corto:", camino)

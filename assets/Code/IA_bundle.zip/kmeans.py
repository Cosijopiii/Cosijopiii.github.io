#%%
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.datasets import load_iris
from sklearn.metrics import silhouette_score

# Cargar el dataset de iris
iris = load_iris()
X = iris.data  # Características (sépalos y pétalos)
y_true = iris.target  # Etiquetas reales (especies de iris)

# Definir la función para visualizar los clusters
def visualizar_clusters(X, y_kmeans, centers):
    plt.scatter(X[:, 0], X[:, 1], c=y_kmeans, s=50, cmap='viridis')
    plt.scatter(centers[:, 0], centers[:, 1], c='black', s=200, alpha=0.5)
    plt.xlabel('Longitud del sépalo')
    plt.ylabel('Ancho del sépalo')
    plt.title('Clustering K-means')
    plt.show()

# Elegir el número de clusters (K)
num_clusters = 3

# Crear y ajustar el modelo K-means
kmeans = KMeans(n_clusters=num_clusters, random_state=0)
kmeans.fit(X)

# Obtener las etiquetas de los clusters
y_kmeans = kmeans.predict(X)

# Evaluar el modelo
# Calcular la suma de los cuadrados de las distancias dentro de los clusters (SSE)
sse = kmeans.inertia_
print("SSE:", sse)

# Calcular el índice de silueta
silhouette_avg = silhouette_score(X, y_kmeans)
print("Silhouette score:", silhouette_avg)

# Visualizar los resultados
centers = kmeans.cluster_centers_
visualizar_clusters(X, y_kmeans, centers)

# Método del codo para encontrar el número óptimo de clusters
sse = []
for k in range(1, 11):
    kmeans = KMeans(n_clusters=k, random_state=0)
    kmeans.fit(X)
    sse.append(kmeans.inertia_)

# Graficar el método del codo
plt.plot(range(1, 11), sse)
plt.xlabel("Número de clusters")
plt.ylabel("SSE")
plt.title("Método del codo")
plt.show()
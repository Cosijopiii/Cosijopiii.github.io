#%%
import pandas as pd
import numpy as np

# Definir el dataset PlayTennis
data = {
    'Outlook': ['Sunny', 'Sunny', 'Overcast', 'Rain', 'Rain', 'Rain', 'Overcast', 'Sunny', 'Sunny', 'Rain', 'Sunny', 'Overcast', 'Overcast', 'Rain'],
    'Temperature': ['Hot', 'Hot', 'Hot', 'Mild', 'Cool', 'Cool', 'Cool', 'Mild', 'Cool', 'Mild', 'Mild', 'Mild', 'Hot', 'Mild'],
    'Humidity': ['High', 'High', 'High', 'High', 'Normal', 'Normal', 'Normal', 'High', 'Normal', 'Normal', 'Normal', 'High', 'Normal', 'High'],
    'Windy': [False, True, False, False, False, True, True, False, False, False, True, True, False, True],
    'PlayTennis': ['No', 'No', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No']
}

df = pd.DataFrame(data)


def entropy(target_col):
    """
    Calcula la entropía de una columna objetivo.

    Parameters:
    target_col (pd.Series): La columna objetivo para la cual se calculará la entropía.

    Returns:
    float: La entropía de la columna objetivo.

    La entropía mide la cantidad de incertidumbre o impureza en un conjunto de datos.
    Se calcula utilizando la fórmula de entropía de Shannon:
    H(X) = -sum(p(x) * log2(p(x))) para cada valor único x en el conjunto de datos.
    """
    elements, counts = np.unique(target_col, return_counts=True)
    entropy = np.sum([(-counts[i]/np.sum(counts)) * np.log2(counts[i]/np.sum(counts)) for i in range(len(elements))])
    return entropy
# Función para calcular la ganancia de información
def info_gain(data, split_attribute_name, target_name="PlayTennis"):
    """
    Calcula la ganancia de información para un atributo específico en un conjunto de datos.

    Parameters:
    data (pd.DataFrame): El conjunto de datos.
    split_attribute_name (str): El nombre del atributo por el cual se dividirá el conjunto de datos.
    target_name (str): El nombre del atributo objetivo. Por defecto es "PlayTennis".

    Returns:
    float: La ganancia de información.

    La ganancia de información mide la reducción en la entropía (incertidumbre) al dividir un conjunto de datos en subconjuntos basados en un atributo.

    1. Calcular la entropía total del conjunto de datos:
       total_entropy = entropy(data[target_name])
       La entropía total se calcula utilizando la función `entropy`, que mide la cantidad de incertidumbre en el conjunto de datos. La fórmula de la entropía de Shannon es:
       H(X) = -sum(p(x_i) * log2(p(x_i))) para cada valor único x_i en el conjunto de datos.

    2. Obtener los valores únicos del atributo de división y sus conteos:
       vals, counts = np.unique(data[split_attribute_name], return_counts=True)
       Aquí, `vals` contiene los valores únicos del atributo de división y `counts` contiene el número de ocurrencias de cada valor.

    3. Calcular la entropía ponderada de los subconjuntos:
       weighted_entropy = np.sum([(counts[i]/np.sum(counts)) * entropy(data.where(data[split_attribute_name] == vals[i]).dropna()[target_name]) for i in range(len(vals))])
       La entropía ponderada se calcula sumando la entropía de cada subconjunto, ponderada por la proporción de muestras en ese subconjunto. La fórmula es:
       H_ponderada = sum((counts_i / sum(counts)) * H(subconjunto_i)) para cada subconjunto_i.

    4. Calcular la ganancia de información:
       information_gain = total_entropy - weighted_entropy
       La ganancia de información se calcula restando la entropía ponderada de la entropía total:
       Ganancia de Información = H(total) - H_ponderada
       donde H(total) es la entropía total del conjunto de datos y H_ponderada es la entropía ponderada de los subconjuntos.
    """
    total_entropy = entropy(data[target_name])
    vals, counts = np.unique(data[split_attribute_name], return_counts=True)
    weighted_entropy = np.sum([(counts[i]/np.sum(counts)) * entropy(data.where(data[split_attribute_name] == vals[i]).dropna()[target_name]) for i in range(len(vals))])
    information_gain = total_entropy - weighted_entropy
    return information_gain

# Función para construir el árbol de decisión
def ID3(data, original_data, features, target_attribute_name="PlayTennis", parent_node_class=None):
    """
    Construye un árbol de decisión utilizando el algoritmo ID3.

    Parameters:
    data (pd.DataFrame): El conjunto de datos actual.
    original_data (pd.DataFrame): El conjunto de datos original.
    features (list): Lista de nombres de atributos.
    target_attribute_name (str): El nombre del atributo objetivo. Por defecto es "PlayTennis".
    parent_node_class: La clase del nodo padre.

    Returns:
    dict or str: El árbol de decisión construido o la clase objetivo.

    El algoritmo ID3 construye un árbol de decisión seleccionando el atributo que maximiza la ganancia de información en cada paso.
    La ganancia de información mide la reducción en la entropía al dividir un conjunto de datos en subconjuntos basados en un atributo.

    1. Si todos los ejemplos tienen la misma clase, se devuelve esa clase.
    2. Si el conjunto de datos está vacío, se devuelve la clase mayoritaria del conjunto de datos original.
    3. Si no hay más atributos para dividir, se devuelve la clase mayoritaria del nodo padre.
    4. En caso contrario, se selecciona el atributo que maximiza la ganancia de información y se construye un nodo para ese atributo.
       Luego, se construyen subárboles recursivamente para cada valor del atributo seleccionado.
    """
    if len(np.unique(data[target_attribute_name])) <= 1:
        return np.unique(data[target_attribute_name])[0]
    elif len(data) == 0:
        return np.unique(original_data[target_attribute_name])[np.argmax(np.unique(original_data[target_attribute_name], return_counts=True)[1])]
    elif len(features) == 0:
        return parent_node_class
    else:
        parent_node_class = np.unique(data[target_attribute_name])[np.argmax(np.unique(data[target_attribute_name], return_counts=True)[1])]
        item_values = [info_gain(data, feature, target_attribute_name) for feature in features]
        best_feature_index = np.argmax(item_values)
        best_feature = features[best_feature_index]
        tree = {best_feature: {}}
        features = [i for i in features if i != best_feature]
        for value in np.unique(data[best_feature]):
            sub_data = data.where(data[best_feature] == value).dropna()
            subtree = ID3(sub_data, data, features, target_attribute_name, parent_node_class)
            tree[best_feature][value] = subtree
        return tree

def print_tree(tree, path=""):
    if not isinstance(tree, dict):
        print(f"{path} -> {tree}")
    else:
        for key, value in tree.items():
            print_tree(value, f"{path}/{key}")

# Imprimir el árbol de decisión

# Construir el árbol de decisión


def predict(tree, instance):
    if not isinstance(tree, dict):
        return tree
    else:
        root_node = next(iter(tree))
        value = instance[root_node]
        subtree = tree[root_node].get(value, None)
        if subtree is None:
            return None
        return predict(subtree, instance)

def calculate_accuracy(tree, data, target_attribute_name="PlayTennis"):
    correct_predictions = 0
    for i in range(len(data)):
        instance = data.iloc[i]
        if predict(tree, instance) == instance[target_attribute_name]:
            correct_predictions += 1
    accuracy = correct_predictions / len(data)
    return accuracy

# Crear un nuevo DataFrame con datos no vistos para probar la precisión
test_data = {
    'Outlook': ['Sunny', 'Rain', 'Overcast'],
    'Temperature': ['Cool', 'Hot', 'Mild'],
    'Humidity': ['High', 'Normal', 'High'],
    'Windy': [True, False, True],
    'PlayTennis': ['No', 'Yes', 'Yes']
}

features = list(df.columns)
features.remove('PlayTennis')

tree = ID3(df, df, features)
print_tree(tree)


test_df = pd.DataFrame(test_data)

# Calcular la precisión del modelo
accuracy = calculate_accuracy(tree, test_df)
print(f"Accuracy: {accuracy * 100:.2f}%")

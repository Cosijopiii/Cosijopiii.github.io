# Basico de Naive Bayes en Python
#%%
# Teoria basica:
# El clasificador Naive Bayes es un modelo probabilistico basado en el teorema de Bayes:
# P(A|B) = P(B|A) * P(A) / P(B)
# Donde P(A|B) es la probabilidad posterior, P(B|A) es la verosimilitud, P(A) es la probabilidad previa, y P(B) es la evidencia.
# Naive Bayes asume que todas las caracteristicas son independientes entre si.

# Importar librerias necesarias
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_iris
import numpy as np

# Generar datos de ejemplo
# Vamos a crear un conjunto de datos simple con dos clases (0 y 1) y dos caracteristicas
np.random.seed(42)
X = np.random.rand(100, 2)  # 100 muestras con 2 caracteristicas cada una
y = np.random.choice([0, 1], size=100)  # Etiquetas de clase aleatorias

# Dividir los datos en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Crear e inicializar el clasificador Naive Bayes
model = GaussianNB()

# Entrenar el modelo
model.fit(X_train, y_train)

# Hacer predicciones
y_pred = model.predict(X_test)

# Evaluar la precision del modelo
accuracy = accuracy_score(y_test, y_pred)
print(f"Exactitud del modelo: {accuracy:.2f}")

# Ejemplo de prediccion con nuevos datos
new_data = np.array([[0.6, 0.2], [0.1, 0.8]])  # Nuevas muestras para clasificar
predictions = model.predict(new_data)
print(f"Predicciones para nuevos datos: {predictions}")

# Ejemplo con un dataset real: Iris
# Cargamos el dataset Iris de sklearn
iris = load_iris()
X_real = iris.data  # Caracteristicas: largo y ancho de sepalo y petalo
y_real = iris.target  # Etiquetas de clase: 0, 1, 2 (tres especies de iris)

# Dividir los datos en entrenamiento y prueba
X_train_real, X_test_real, y_train_real, y_test_real = train_test_split(X_real, y_real, test_size=0.2, random_state=42)

# Crear e inicializar el clasificador Naive Bayes
model_real = GaussianNB()

# Entrenar el modelo
model_real.fit(X_train_real, y_train_real)

# Hacer predicciones
y_pred_real = model_real.predict(X_test_real)

# Evaluar la precision del modelo
accuracy_real = accuracy_score(y_test_real, y_pred_real)
print(f"Exactitud del modelo con el dataset Iris: {accuracy_real:.2f}")

# Ejemplo de prediccion con nuevos datos del dataset Iris
new_data_real = np.array([[5.1, 3.5, 1.4, 0.2], [6.7, 3.1, 4.7, 1.5]])  # Nuevas muestras para clasificar
predictions_real = model_real.predict(new_data_real)
print(f"Predicciones para nuevos datos del dataset Iris: {predictions_real}")

# Conclusiones:
# Este ejemplo muestra como usar Naive Bayes para clasificacion con datos simples y con un dataset real (Iris).
# En aplicaciones reales, es importante preparar adecuadamente los datos (normalizacion, limpieza) para mejorar el rendimiento.

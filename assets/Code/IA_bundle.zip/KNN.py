#%%
import numpy as np
import matplotlib.pyplot as plt
import sklearn.neural_network
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA
import seaborn as sns

# Cargar la base de datos Iris
iris = load_iris()
X = iris.data  # Usamos las cuatro características
y = iris.target

# Reducir las dimensiones con PCA
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

# Visualización de los datos en 2D usando PCA
plt.figure(figsize=(8, 6))
for i, target_name in enumerate(iris.target_names):
    plt.scatter(X_pca[y == i, 0], X_pca[y == i, 1], label=target_name, alpha=0.7)
plt.title("Visualización de Iris usando PCA")
plt.xlabel("Componente Principal 1")
plt.ylabel("Componente Principal 2")
plt.legend()
plt.grid()
plt.show()

# Dividir los datos en conjunto de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

# Visualización de las distribuciones de las características originales
features = iris.feature_names
plt.figure(figsize=(16, 10))
for i in range(4):
    plt.subplot(2, 2, i + 1)
    sns.kdeplot(x=X[:, i], hue=y, fill=True, palette="muted", common_norm=False, alpha=0.5, label=iris.target_names)
    plt.title(f"Distribución de {features[i]}")
    plt.xlabel(features[i])
    plt.ylabel("Densidad")
    plt.legend(title="Clases", labels=iris.target_names)
    plt.grid()
plt.tight_layout()
plt.show()

# Entrenar un clasificador KNN
k =20
knn = KNeighborsClassifier(n_neighbors=k)
knn.fit(X_train, y_train)
# Predicción en el conjunto de prueba
y_pred = knn.predict(X_test)

# Calcular la precisión del modelo
accuracy = accuracy_score(y_test, y_pred)
print(f"Precisión del modelo KNN: {accuracy * 100:.2f}%")

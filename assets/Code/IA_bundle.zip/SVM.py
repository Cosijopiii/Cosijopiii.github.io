#%%
# Importar librerías necesarias
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification, make_circles
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

# ================================================
# EJEMPLO 1: Clasificación Lineal con SVM
# ================================================

# Crear un dataset linealmente separable
X, y = make_classification(
    n_samples=100, n_features=2, n_informative=2, n_redundant=0,
    n_clusters_per_class=1, class_sep=2.0, random_state=42
)

# Dividir en datos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Entrenar un SVM lineal
svm_linear = SVC(kernel='linear', C=1.0)
svm_linear.fit(X_train, y_train)

# Visualizar los datos y el hiperplano de decisión
def plot_svm_decision_boundary(model, X, y):
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap='viridis', s=30)
    ax = plt.gca()
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    xx, yy = np.meshgrid(
        np.linspace(xlim[0], xlim[1], 50),
        np.linspace(ylim[0], ylim[1], 50)
    )
    Z = model.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.contour(xx, yy, Z, colors='k', levels=[-1, 0, 1], alpha=0.7, linestyles=['--', '-', '--'])
    plt.scatter(model.support_vectors_[:, 0], model.support_vectors_[:, 1], s=100, facecolors='none', edgecolors='k', label='Soporte')
    plt.title("SVM Lineal - Hiperplano de Decisión")
    plt.legend()
    plt.show()

plot_svm_decision_boundary(svm_linear, X, y)

# Evaluar el modelo
y_pred = svm_linear.predict(X_test)
print("Reporte de Clasificación (SVM Lineal):")
print(classification_report(y_test, y_pred))

# ================================================
# EJEMPLO 2: Clasificación No Lineal con Kernel RBF
# ================================================
#%%
# Crear un dataset no lineal (en forma de círculos)
X, y = make_circles(n_samples=200, noise=0.1, factor=0.3, random_state=42)

# Dividir en datos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Entrenar un SVM con kernel RBF
svm_rbf = SVC(kernel='rbf', C=1.0, gamma=0.5)
svm_rbf.fit(X_train, y_train)

# Visualizar los datos y las regiones de decisión
def plot_svm_nonlinear_decision_boundary(model, X, y):
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap='viridis', s=30)
    ax = plt.gca()
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    xx, yy = np.meshgrid(
        np.linspace(xlim[0], xlim[1], 50),
        np.linspace(ylim[0], ylim[1], 50)
    )
    Z = model.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.contourf(xx, yy, Z, levels=20, cmap='coolwarm', alpha=0.6)
    plt.scatter(model.support_vectors_[:, 0], model.support_vectors_[:, 1], s=100, facecolors='none', edgecolors='k', label='Soporte')
    plt.title("SVM con Kernel RBF - Regiones de Decisión")
    plt.legend()
    plt.show()

plot_svm_nonlinear_decision_boundary(svm_rbf, X, y)

# Evaluar el modelo
y_pred_rbf = svm_rbf.predict(X_test)
print("Reporte de Clasificación (SVM con Kernel RBF):")
print(classification_report(y_test, y_pred_rbf))

# ================================================
# EJEMPLO 3: Cambiando Parámetros del SVM
# ================================================

# Entrenar un SVM con un valor menor de C (mayor margen pero más errores)
svm_soft_margin = SVC(kernel='linear', C=0.1)
svm_soft_margin.fit(X_train, y_train)

# Visualizar los resultados
plot_svm_decision_boundary(svm_soft_margin, X, y)

# Evaluar el modelo con C pequeño
y_pred_soft_margin = svm_soft_margin.predict(X_test)
print("Reporte de Clasificación (SVM con C bajo):")
print(classification_report(y_test, y_pred_soft_margin))

#%%
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.datasets import make_circles
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# ================================================
# Generar un dataset no lineal
# ================================================
X, y = make_circles(n_samples=300, noise=0.05, factor=0.3, random_state=42)

# Añadir una nueva dimensión: el radio cuadrado
X_new = np.hstack((X, (X[:, 0]**2 + X[:, 1]**2).reshape(-1, 1)))

# Dividir en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_new, y, test_size=0.3, random_state=42)

# Entrenar un SVM lineal en el espacio 3D
svm_3d = SVC(kernel='linear', C=1.0)
svm_3d.fit(X_train, y_train)

# ================================================
# Visualización en 3D
# ================================================
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# Plot de puntos
scatter = ax.scatter(X_new[:, 0], X_new[:, 1], X_new[:, 2], c=y, cmap='viridis', s=50)
legend1 = ax.legend(*scatter.legend_elements(), title="Clases")
ax.add_artist(legend1)

# Definir los límites del espacio
xlim, ylim, zlim = ax.get_xlim(), ax.get_ylim(), ax.get_zlim()

# Crear una malla para el hiperplano
xx, yy = np.meshgrid(np.linspace(xlim[0], xlim[1], 20), np.linspace(ylim[0], ylim[1], 20))
zz = (-svm_3d.coef_[0, 0] * xx - svm_3d.coef_[0, 1] * yy - svm_3d.intercept_) / svm_3d.coef_[0, 2]

# Dibujar el hiperplano
ax.plot_surface(xx, yy, zz, color='orange', alpha=0.5, rstride=100, cstride=100)

# Etiquetas y título
ax.set_title("Separación Lineal en el Espacio 3D")
ax.set_xlabel("X1")
ax.set_ylabel("X2")
ax.set_zlabel("X1^2 + X2^2")
plt.show()

# ================================================
# Evaluación del modelo
# ================================================
y_pred = svm_3d.predict(X_test)
print("Reporte de Clasificación (SVM en 3D):")
print(classification_report(y_test, y_pred))


#%%
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_circles
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay

# ================================================
# Generar un dataset no lineal
# ================================================
X, y = make_circles(n_samples=300, noise=0.05, factor=0.3, random_state=42)

# Dividir en datos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# ================================================
# Entrenar un SVM con kernel RBF
# ================================================
svm_rbf = SVC(kernel='rbf', C=1.0, gamma='scale')
svm_rbf.fit(X_train, y_train)

# Predicciones
y_pred = svm_rbf.predict(X_test)

# ================================================
# Visualización de la frontera de decisión
# ================================================
# Crear una malla de puntos para visualizar
x_min, x_max = X[:, 0].min() - 0.5, X[:, 0].max() + 0.5
y_min, y_max = X[:, 1].min() - 0.5, X[:, 1].max() + 0.5
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.01),
                     np.arange(y_min, y_max, 0.01))

# Predecir valores para cada punto de la malla
Z = svm_rbf.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Dibujar la frontera de decisión
plt.figure(figsize=(8, 6))
plt.contourf(xx, yy, Z, alpha=0.8, cmap='viridis')
plt.scatter(X[:, 0], X[:, 1], c=y, cmap='viridis', edgecolor='k')
plt.title("Clasificación con SVM y Kernel RBF")
plt.xlabel("X1")
plt.ylabel("X2")
plt.show()

# ================================================
# Evaluación del modelo
# ================================================
print("Reporte de Clasificación:")
print(classification_report(y_test, y_pred))

# Matriz de confusión
conf_matrix = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(conf_matrix, display_labels=["Clase 0", "Clase 1"])
disp.plot(cmap='Blues')
plt.title("Matriz de Confusión")
plt.show()
#%%
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay

# ================================================
# Cargar el dataset Iris
# ================================================
iris = datasets.load_iris()
X = iris.data[:, :2]  # Usamos solo las dos primeras características (sepal length y width)
y = iris.target       # Las etiquetas (0: Setosa, 1: Versicolor, 2: Virginica)

# Dividir en datos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# ================================================
# Entrenar un SVM con kernel RBF
# ================================================
svm_rbf = SVC(kernel='rbf', C=1.0, gamma='scale', decision_function_shape='ovo')
svm_rbf.fit(X_train, y_train)

# Predicciones
y_pred = svm_rbf.predict(X_test)

# ================================================
# Visualización de la frontera de decisión
# ================================================
# Crear una malla de puntos para visualizar
x_min, x_max = X[:, 0].min() - 0.5, X[:, 0].max() + 0.5
y_min, y_max = X[:, 1].min() - 0.5, X[:, 1].max() + 0.5
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.01),
                     np.arange(y_min, y_max, 0.01))

# Predecir valores para cada punto de la malla
Z = svm_rbf.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Dibujar la frontera de decisión
plt.figure(figsize=(8, 6))
plt.contourf(xx, yy, Z, alpha=0.8, cmap='viridis')
scatter = plt.scatter(X[:, 0], X[:, 1], c=y, cmap='viridis', edgecolor='k')
plt.title("Clasificación con SVM y Kernel RBF - Dataset Iris")
plt.xlabel("Longitud del Sépalo")
plt.ylabel("Ancho del Sépalo")
plt.legend(*scatter.legend_elements(), title="Clases")
plt.show()

# ================================================
# Evaluación del modelo
# ================================================
print("Reporte de Clasificación:")
print(classification_report(y_test, y_pred, target_names=iris.target_names))

# Matriz de confusión
conf_matrix = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(conf_matrix, display_labels=iris.target_names)
disp.plot(cmap='Blues')
plt.title("Matriz de Confusión")
plt.show()

#%%
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay

# ================================================
# Cargar el dataset Iris
# ================================================
iris = datasets.load_iris()
X = iris.data       # Usamos todas las características
y = iris.target     # Las etiquetas (0: Setosa, 1: Versicolor, 2: Virginica)

# Dividir en datos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# ================================================
# Entrenar un SVM con kernel RBF
# ================================================
svm_rbf = SVC(kernel='rbf', C=1.0, gamma='scale', decision_function_shape='ovo')
svm_rbf.fit(X_train, y_train)

# Predicciones
y_pred = svm_rbf.predict(X_test)

# ================================================
# Reducción de dimensionalidad con PCA para visualización
# ================================================
# Reducir a 2 dimensiones para visualizar con PCA
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

# Aplicar PCA también a los datos de prueba para visualización
X_test_pca = pca.transform(X_test)

# Dibujar la frontera de decisión en el espacio reducido
x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.01),
                     np.arange(y_min, y_max, 0.01))

# Predecir para cada punto en la malla (espacio PCA)
Z = svm_rbf.predict(pca.inverse_transform(np.c_[xx.ravel(), yy.ravel()]))
Z = Z.reshape(xx.shape)

# Plot de la frontera de decisión
plt.figure(figsize=(10, 6))
plt.contourf(xx, yy, Z, alpha=0.8, cmap='viridis')
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap='viridis', edgecolor='k')
plt.title("Clasificación con SVM y Kernel RBF - Dataset Iris (Reducción con PCA)")
plt.xlabel("Componente Principal 1")
plt.ylabel("Componente Principal 2")
plt.legend(*scatter.legend_elements(), title="Clases")
plt.grid()
plt.show()

# ================================================
# Evaluación del modelo
# ================================================
print("Reporte de Clasificación:")
print(classification_report(y_test, y_pred, target_names=iris.target_names))

# Matriz de confusión
conf_matrix = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(conf_matrix, display_labels=iris.target_names)
disp.plot(cmap='Blues')
plt.title("Matriz de Confusión")
plt.show()

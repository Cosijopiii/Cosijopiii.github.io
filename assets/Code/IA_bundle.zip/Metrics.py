#%%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, ConfusionMatrixDisplay, roc_curve, auc
)
from sklearn.preprocessing import label_binarize, StandardScaler

# ================================================
# DOCUMENTACIÓN SOBRE MÉTRICAS Y VISUALIZACIONES
# ================================================
# Matriz de confusión:
# Representa el desempeño del modelo clasificando instancias en categorías correctas e incorrectas.
# Cada fila de la matriz representa las instancias reales de una clase, y cada columna las predicciones.
#
# Fórmula para las métricas derivadas:
# Precisión (Precision) = TP / (TP + FP)  -> Qué proporción de las predicciones positivas fueron correctas.
# Exhaustividad (Recall o Sensibilidad) = TP / (TP + FN) -> Qué proporción de los positivos reales fue identificada.
# F1-Score = 2 * (Precisión * Recall) / (Precisión + Recall)
#
# Curva ROC (Receiver Operating Characteristic):
# Muestra la relación entre la Tasa de Verdaderos Positivos (TPR) y la Tasa de Falsos Positivos (FPR).
# Área bajo la curva (AUC): Mide la capacidad del modelo para diferenciar entre clases.
# Fórmulas:
#   TPR = TP / (TP + FN)  -> Tasa de Verdaderos Positivos
#   FPR = FP / (FP + TN)  -> Tasa de Falsos Positivos
#
# ================================================

# ================================================
# EXPLICACIÓN DETALLADA DE MÉTRICAS DE EVALUACIÓN
# ================================================
# 1. Precisión (Precision):
# Indica qué porcentaje de las predicciones positivas del modelo son realmente positivas.
# Una alta precisión significa que el modelo tiene pocos falsos positivos.
# Fórmula: Precision = TP / (TP + FP)
#
# 2. Exhaustividad (Recall o Sensibilidad):
# Indica qué porcentaje de las instancias positivas reales fueron correctamente identificadas por el modelo.
# Una alta sensibilidad significa que el modelo tiene pocos falsos negativos.
# Fórmula: Recall = TP / (TP + FN)
#
# 3. F1-Score:
# Es la media armónica entre la precisión y la exhaustividad. Es útil cuando hay un desequilibrio en las clases.
# Fórmula: F1-Score = 2 * (Precision * Recall) / (Precision + Recall)
#
# 4. Curva ROC y AUC:
# La curva ROC visualiza el trade-off entre TPR (Tasa de Verdaderos Positivos) y FPR (Tasa de Falsos Positivos) a diferentes umbrales.
# El área bajo la curva (AUC) proporciona una medida agregada del desempeño del modelo.
# Una AUC cercana a 1 indica un modelo excelente, mientras que un AUC cercano a 0.5 indica un modelo aleatorio.
#
# Ejemplo Práctico:
# - Un modelo con alta precisión pero bajo recall puede ser útil para casos donde los falsos positivos sean costosos (e.g., diagnósticos médicos).
# - Un modelo con alto recall pero baja precisión puede ser útil para casos donde es crítico capturar todos los positivos (e.g., detección de fraudes).
# ================================================

# Cargar el dataset de calidad del vino
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
wine_data = pd.read_csv(url, delimiter=';')

# Separar características y etiquetas
X = wine_data.iloc[:, :-1].values  # Las primeras 11 columnas son las características
y = wine_data['quality'].values    # La última columna es la etiqueta

# Estandarizar las características
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Binarizar etiquetas para curva ROC (consideramos calidad >= 6 como positiva)
threshold = 6
y_binarized = (y >= threshold).astype(int)

# Dividir los datos en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y_binarized, test_size=0.3, random_state=42, stratify=y_binarized)

# Entrenar un modelo Random Forest
clf = RandomForestClassifier(random_state=42, n_estimators=100)
clf.fit(X_train, y_train)

# Predicciones
y_pred = clf.predict(X_test)
probas = clf.predict_proba(X_test)[:, 1]  # Probabilidades para la clase positiva

# Reporte de clasificación
print("Reporte de Clasificación:\n")
print(classification_report(y_test, y_pred, target_names=["Baja calidad", "Alta calidad"]))

# Matriz de confusión
conf_matrix = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(conf_matrix, display_labels=["Baja calidad", "Alta calidad"])
disp.plot(cmap='Blues')
plt.title("Matriz de Confusión")
plt.show()

# Curva ROC
fpr, tpr, trh = roc_curve(y_test, probas)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f"ROC curve (AUC = {roc_auc:.2f})")
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('Tasa de Falsos Positivos (FPR)')
plt.ylabel('Tasa de Verdaderos Positivos (TPR)')
plt.title('Curva ROC - Calidad del Vino')
plt.legend(loc="lower right")
plt.grid()
plt.show()

# Definir la clase Pila con los métodos push y pop
import networkx as nx
import matplotlib.pyplot as plt

class Pila:
    def __init__(self):
        self.items = []

    # Método para agregar un elemento a la pila
    def push(self, item):
        self.items.append(item)

    # Método para sacar un elemento de la pila
    def pop(self):
        if not self.is_empty():
            return self.items.pop()
        return None

    # Método para verificar si la pila está vacía
    def is_empty(self):
        return len(self.items) == 0


# Implementación iterativa de DFS usando una pila personalizada
def dfs_iterative(graph, start):
    visited = set()  # Conjunto para rastrear nodos visitados
    stack = Pila()  # Crear una instancia de la clase Pila
    stack.push(start)  # Agregar el nodo inicial a la pila

    while not stack.is_empty():
        # Sacar el último nodo de la pila
        node = stack.pop()

        # Si el nodo no ha sido visitado, lo marcamos como visitado
        if node not in visited:
            print(node, end=' ')  # Imprimir el nodo visitado
            visited.add(node)

            # Añadir los nodos adyacentes no visitados a la pila
            # Usamos reversed() para mantener el orden similar al DFS recursivo
            for neighbor in reversed(graph[node]):
                if neighbor not in visited:
                    stack.push(neighbor)


graph= {
    'A': ['B', 'C'],          # Raíz
    'B': ['D', 'E'],          # Hijo izquierdo de A
    'C': ['F', 'G'],          # Hijo derecho de A
    'D': ['H', 'I'],          # Hijo izquierdo de B
    'E': ['J', 'K'],          # Hijo derecho de B
    'F': ['L', 'M'],          # Hijo izquierdo de C
    'G': ['N', 'O'],          # Hijo derecho de C
    'H': [],                  # Hijo izquierdo de D
    'I': ['P'],               # Hijo derecho de D
    'J': [],                  # Hijo izquierdo de E
    'K': [],                  # Hijo derecho de E
    'L': [],                  # Hijo izquierdo de F
    'M': ['Q'],               # Hijo derecho de F
    'N': [],                  # Hijo izquierdo de G
    'O': [],                  # Hijo derecho de G
    'P': [],                  # Hijo izquierdo de I
    'Q': [],                  # Hijo derecho de M
}

# Grafo más grande y complicado con ciclos
# graph = {
#     'A': ['B', 'C', 'D'],
#     'B': ['E', 'F'],
#     'C': ['G', 'H'],
#     'D': ['I', 'J'],
#     'E': ['K', 'L'],
#     'F': ['M', 'N'],
#     'G': ['O', 'P'],
#     'H': ['Q', 'R'],
#     'I': ['S', 'T'],
#     'J': ['U', 'V'],
#     'K': ['A', 'W'],  # Ciclo de vuelta a 'A'
#     'L': [],
#     'M': ['X'],
#     'N': [],
#     'O': [],
#     'P': ['Q'],
#     'Q': ['F'],  # Ciclo de vuelta a 'F'
#     'R': [],
#     'S': [],
#     'T': ['J'],  # Ciclo de vuelta a 'J'
#     'U': [],
#     'V': [],
#     'W': [],
#     'X': []
# }

# Llamada a la función DFS iterativa
dfs_iterative(graph, 'A')


def graficar_grafo(graph):
    # Crear un objeto de grafo dirigido
    G = nx.DiGraph()

    # Añadir los nodos y las aristas al grafo
    for node, neighbors in graph.items():
        for neighbor in neighbors:
            G.add_edge(node, neighbor)

    # Dibujar el grafo
    pos = nx.spring_layout(G)  # Posicionamiento de los nodos
    nx.draw(G, pos, with_labels=True, arrows=True)
    plt.title("Grafo")
    plt.show()

# Llamada al método para graficar el grafo
graficar_grafo(graph)

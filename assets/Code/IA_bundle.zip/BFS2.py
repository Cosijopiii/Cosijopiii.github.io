# Definición de la clase Cola



import networkx as nx
import matplotlib.pyplot as plt

class Cola:
    def __init__(self):
        self.items = []

    # Método para agregar un elemento a la cola
    def enqueue(self, item):
        self.items.append(item)

    # Método para sacar un elemento de la cola
    def dequeue(self):
        if not self.is_empty():
            return self.items.pop(0)
        return None

    # Método para verificar si la cola está vacía
    def is_empty(self):
        return len(self.items) == 0

# Implementación de BFS usando una cola personalizada
def bfs(graph, start):
    visited = set()  # Conjunto para rastrear nodos visitados
    queue = Cola()   # Crear una instancia de la clase Cola
    queue.enqueue(start)  # Agregar el nodo inicial a la cola
    visited.add(start)  # Marcar el nodo inicial como visitado

    while not queue.is_empty():
        # Sacar el primer nodo de la cola
        node = queue.dequeue()
        print(node, end=' ')  # Imprimir el nodo visitado

        # Añadir los nodos adyacentes no visitados a la cola
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)  # Marcar como visitado
                queue.enqueue(neighbor)  # Agregar a la cola

# Definición de un grafo (puedes usar el árbol binario complejo de antes)
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F', 'G'],
    'D': ['H', 'I'],
    'E': ['J', 'K'],
    'F': ['L', 'M'],
    'G': ['N', 'O'],
    'H': [],
    'I': ['P'],
    'J': [],
    'K': [],
    'L': [],
    'M': ['Q'],
    'N': [],
    'O': [],
    'P': [],
    'Q': [],
}

# Llamada a la función BFS
bfs(graph, 'A')

def graficar_grafo(graph):
    # Crear un objeto de grafo dirigido
    G = nx.DiGraph()

    # Añadir los nodos y las aristas al grafo
    for node, neighbors in graph.items():
        for neighbor in neighbors:
            G.add_edge(node, neighbor)

    # Dibujar el grafo
    pos = nx.spring_layout(G,scale=3)  # Posicionamiento de los nodos
    nx.draw(G, pos, with_labels=True, arrows=True)
    plt.title("Grafo")
    plt.show()

# Llamada al método para graficar el grafo
graficar_grafo(graph)